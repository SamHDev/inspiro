class InsprioBotError(Exception):
    pass